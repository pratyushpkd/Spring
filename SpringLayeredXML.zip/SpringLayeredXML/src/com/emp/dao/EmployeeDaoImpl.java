package com.emp.dao;

import java.util.HashMap;
import java.util.Map;

import com.emp.bean.Employee;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	Map<Integer, Employee> map=new HashMap<Integer, Employee>();
	
	
	public void addEmployee(Employee emp) {
		map.put(emp.getEmployeeId(), emp);
	}

}
