package com.cg.spring;

import java.util.List;

public class SBU {

	private int sbuId;
	private String sbuName;
	private String sbuHead;
	private List<Employee> listEmp;
	
	public void getSbuDetails(){
		
		System.out.println("SBU details\n--------------------------");
		System.out.println("sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead="
				+ sbuHead + "\n Employee details:----------------");
		
		for(Employee employee : listEmp){
			System.out.println(employee);
		}
	}
	
	
	public SBU() {
		super();
	}

	public SBU(int sbuId, String sbuName, String sbuHead, List<Employee> listEmp) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.listEmp = listEmp;
	}

	public int getSbuId() {
		return sbuId;
	}

	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	public List<Employee> getListEmp() {
		return listEmp;
	}

	public void setListEmp(List<Employee> listEmp) {
		this.listEmp = listEmp;
	}
	
}
