package com.cg.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client {


	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
	
		SBU sbu = (SBU) ctx.getBean("sbu");
		
		sbu.getSbuDetails();
		
		ctx.close();
    
	}
}