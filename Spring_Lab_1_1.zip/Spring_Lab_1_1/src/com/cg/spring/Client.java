package com.cg.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client {


	public static void main(String[] args) {

		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
	
		Employee emp = (Employee) ctx.getBean("employee");
		
		emp.printdetails();
		
		ctx.close();
    
	}
}