package com.igate.spel;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpel {

	public static void main(String[] args) {
		
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		
		CityList city = (CityList) ctx.getBean("cityList");
		
		ArrayList<City> list = city.getCityList();
		
		for(City obj : list){
			System.out.println(obj.getName() + " " + obj.getState() + " " + obj.getPopulation());
		}
		
		ArrayList<String> list1 = city.getCityNames();
		
		for(String str : list1){
			System.out.println(str);
		}

	}

}
