package com.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.bean.EmployeeBean;
import com.ems.dao.IEmployeeDAO;
import com.ems.exception.EmployeeException;

@Service
public class EmployeeSeviceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeDAO employeeDao;
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		return employeeDao.addEmployee(bean);
	}

	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		
		return employeeDao.viewAllEmployees();
	}

}
