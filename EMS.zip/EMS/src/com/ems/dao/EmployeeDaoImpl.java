package com.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDAO {

	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		
		int id=0;
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getEmployeeId();
		} catch (Exception e) {
			throw new EmployeeException("unable to persist in DAO layer"+e.getMessage());
		}
		return id;
	}


	@Override
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException {
		
		List<EmployeeBean> list;
		try {
			TypedQuery<EmployeeBean> query = entityManager.createQuery("Select e from EmployeeBean e", EmployeeBean.class);
			list = query.getResultList();
		} catch (Exception e) {
			
			throw new EmployeeException("unable to fetch records in DAO Layer"+e.getMessage());
		}
		
		return list;
	}

}
