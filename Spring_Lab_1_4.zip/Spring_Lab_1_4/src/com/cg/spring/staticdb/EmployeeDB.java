package com.cg.spring.staticdb;

import java.util.HashMap;

import com.cg.spring.beans.Employee;

public class EmployeeDB {

static HashMap<Integer, Employee> employeeIdMap = getEmployeeIdMap();
	
	static {
		if (employeeIdMap == null) {
			employeeIdMap = new HashMap<Integer, Employee>();
			Employee emp1 = new Employee(101,"Jatin",1500);
			Employee emp2 = new Employee(102,"Abhi",5500);
			Employee emp3 = new Employee(103,"Squirell",2000);
			Employee emp4 = new Employee(104,"Himanshu",5000);

			employeeIdMap.put(1, emp1);
			employeeIdMap.put(2, emp2);
			employeeIdMap.put(3, emp3);
			employeeIdMap.put(4, emp4);
		}
		
		
	}
	
	public static HashMap<Integer, Employee> getEmployeeIdMap() {
		return employeeIdMap;
	}
}