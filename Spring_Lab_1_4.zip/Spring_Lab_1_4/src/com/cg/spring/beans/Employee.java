package com.cg.spring.beans;

import java.util.Scanner;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class Employee{

	private int employeeId;
	private String employeeName;
	private double salary;
	
	
	public Employee() {
		super();
	}


	public Employee(int employeeId, String employeeName, double salary) {
		
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	@Override
	public String toString() {
		return "Employe Info\nEmployee ID        :" + employeeId + "\nEmployee Name      :"
				+ employeeName + "\nEmployee Salary    :" + salary;
	}




	public void init()
			throws BeansException {
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("Employee ID : ");
		int id = scInput.nextInt();
		scInput.nextLine();
		setEmployeeId(id);	
		scInput.close();

	}


	
	
	
	
	
}
