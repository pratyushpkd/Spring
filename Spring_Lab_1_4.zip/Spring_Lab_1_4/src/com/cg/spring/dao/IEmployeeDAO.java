package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.beans.Employee;

public interface IEmployeeDAO {

	public List<Employee> getEmployeedetail();
}
