package com.cg.spring.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.spring.beans.Employee;
import com.cg.spring.staticdb.EmployeeDB;

public class EmployeeDAOImpl implements IEmployeeDAO {

	static HashMap<Integer, Employee> employeeIdMap = EmployeeDB.getEmployeeIdMap();
	
	@Override
	public List<Employee> getEmployeedetail() {
		List<Employee> employees = new ArrayList<Employee>(employeeIdMap.values());
		return employees;
	}

}
