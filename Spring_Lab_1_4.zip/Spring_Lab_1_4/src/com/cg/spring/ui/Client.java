package com.cg.spring.ui;

import com.cg.spring.beans.Employee;
import com.cg.spring.service.EmployeeServiceImpl;
import com.cg.spring.service.IEmployeeService;

public class Client {

	public static void main(String[] args) {

		IEmployeeService employeeService = new EmployeeServiceImpl();
		
		Employee empdetails = employeeService.getEmployeedetail();
		
		System.out.println(empdetails);
	}

}
