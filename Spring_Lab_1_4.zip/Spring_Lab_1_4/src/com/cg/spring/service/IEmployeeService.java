package com.cg.spring.service;

import com.cg.spring.beans.Employee;

public interface IEmployeeService {

	public Employee getEmployeedetail();
}
