package com.cg.spring.service;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.beans.Employee;
import com.cg.spring.dao.EmployeeDAOImpl;
import com.cg.spring.dao.IEmployeeDAO;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDAO employeeDao = new EmployeeDAOImpl();
	@Override
	public Employee getEmployeedetail() {
		
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		
		Employee emp = (Employee) ctx.getBean("employeeclient");
		int empId = emp.getEmployeeId();
		List<Employee> listEmp = employeeDao.getEmployeedetail();
		Employee employeedetailEmployee = new Employee();
			
		for (Employee employee : listEmp) {
			if(employee.getEmployeeId()==empId){
				employeedetailEmployee = employee;
				break;
			}else{
				employeedetailEmployee = null;
			}
		}
		
		ctx.close();
		return employeedetailEmployee;
	}
	

}
