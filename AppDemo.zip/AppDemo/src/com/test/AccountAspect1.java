package com.test;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AccountAspect1 {

	@Before("adviceToAll()")
	public void beforeAdvice(){
		System.out.println(" before advice called ");
	}
	
	@Pointcut("execution (* com.test.*.*())")
	public void adviceToAll(){
		
	}
}
