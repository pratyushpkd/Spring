package com.test;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AccountAspect3 {

	@Around("adviceToAll()")
	public void beforeAdvice(ProceedingJoinPoint pjp) throws Throwable{
		System.out.println(" before advice called ");
		Object obj = pjp.proceed();
		
		int amt = (Integer)obj;
		System.out.println(" after withdrawal Amount = " + amt);

	}
	
	@Pointcut("execution(* com.test.*.*())")
	public void adviceToAll(){
		
	}
}
