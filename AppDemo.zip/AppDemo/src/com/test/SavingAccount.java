package com.test;

public class SavingAccount {

	public void withdraw(){
		System.out.println(" Saving Account withdraw called ");
	}
}
