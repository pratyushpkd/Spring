package com.test;

public class Account {

	public int withdraw(){
		System.out.println("  Account withdraw called  ");
		
		return 100;
	}
}
