package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAccount1 {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring1.xml");
		
		SavingAccount savingAccount = (SavingAccount) ctx.getBean("saving");
		
		savingAccount.withdraw();
	}
}
